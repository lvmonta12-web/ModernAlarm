package com.example.modernalarm

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

data class AlarmItem(val id: Int, val hour: Int, val minute: Int, val enabled: Boolean)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("alarms", Context.MODE_PRIVATE) }
    private lateinit var list: LinearLayout
    private val purple = Color.rgb(139, 124, 255)
    private val bg = Color.rgb(16, 17, 27)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        requestNotificationPermission()
        showExactAlarmPermissionIfNeeded()
        buildUi()
        renderAlarms()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 34, 24, 24)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "Good evening"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        }
        val heading = TextView(this).apply {
            text = "Your alarms"
            textSize = 30f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 20)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val picker = TimePicker(this).apply {
            setIs24HourView(true)
            setBackgroundColor(Color.rgb(29, 30, 45))
        }
        val add = Button(this).apply {
            text = "＋  Add alarm"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, picker.hour)
                    set(Calendar.MINUTE, picker.minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                saveAlarm(AlarmItem(id, picker.hour, picker.minute, true))
                schedule(id, cal.timeInMillis)
                renderAlarms()
                Toast.makeText(this@MainActivity, "Alarm added", Toast.LENGTH_SHORT).show()
            }
        }
        val sub = TextView(this).apply {
            text = "UPCOMING"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(purple)
            setPadding(0, 22, 0, 10)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title)
        root.addView(heading)
        root.addView(picker, LinearLayout.LayoutParams(-1, -2))
        root.addView(add, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 12 })
        root.addView(sub)
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun allAlarms(): MutableList<AlarmItem> {
        val raw = prefs.getString("items", "") ?: ""
        if (raw.isBlank()) return mutableListOf()
        return raw.split(";").mapNotNull {
            val p = it.split(",")
            if (p.size != 4) null else runCatching {
                AlarmItem(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toBoolean())
            }.getOrNull()
        }.toMutableList()
    }

    private fun saveAlarm(item: AlarmItem) {
        val items = allAlarms().filterNot { it.id == item.id }.toMutableList()
        items.add(item)
        prefs.edit().putString("items", items.joinToString(";") { "${it.id},${it.hour},${it.minute},${it.enabled}" }).apply()
    }

    private fun renderAlarms() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val items = allAlarms().sortedBy { it.hour * 60 + it.minute }
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No alarms yet. Add one above."
                setTextColor(Color.LTGRAY)
                textSize = 14f
                setPadding(0, 10, 0, 10)
            })
        }
        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16, 12, 12, 12)
                setBackgroundColor(Color.rgb(29, 30, 45))
            }
            val time = TextView(this).apply {
                text = String.format(Locale.getDefault(), "%02d:%02d", item.hour, item.minute)
                textSize = 28f
                setTextColor(Color.WHITE)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val toggle = Switch(this).apply {
                isChecked = item.enabled
                buttonTintList = android.content.res.ColorStateList.valueOf(purple)
                setOnCheckedChangeListener { _, checked ->
                    saveAlarm(item.copy(enabled = checked))
                    if (checked) scheduleNext(item) else cancel(item.id)
                    renderAlarms()
                }
            }
            val delete = TextView(this).apply {
                text = "  ✕  "
                textSize = 20f
                setTextColor(Color.LTGRAY)
                setOnClickListener {
                    cancel(item.id)
                    val left = allAlarms().filterNot { it.id == item.id }
                    prefs.edit().putString("items", left.joinToString(";") { "${it.id},${it.hour},${it.minute},${it.enabled}" }).apply()
                    renderAlarms()
                }
            }
            row.addView(time, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(toggle)
            row.addView(delete)
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
            list.addView(row, lp)
        }
    }

    private fun scheduleNext(item: AlarmItem) {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, item.hour); set(Calendar.MINUTE, item.minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        schedule(item.id, c.timeInMillis)
    }

    private fun schedule(id: Int, time: Long) {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(this, id, Intent(this, AlarmReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            else am.setExact(AlarmManager.RTC_WAKEUP, time, pi)
        } catch (_: SecurityException) {
            Toast.makeText(this, "Allow exact alarms in Settings to use reliable alarms.", Toast.LENGTH_LONG).show()
        }
    }

    private fun cancel(id: Int) {
        val pi = PendingIntent.getBroadcast(this, id, Intent(this, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("alarm_channel", "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alarm notifications"
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun showExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                AlertDialog.Builder(this).setTitle("Allow exact alarms")
                    .setMessage("For alarms to ring at the selected time, allow exact alarms in the next screen.")
                    .setPositiveButton("Open settings") { _, _ ->
                        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                    }.setNegativeButton("Later", null).show()
            }
        }
    }
}
