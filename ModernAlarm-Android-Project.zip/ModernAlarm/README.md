# Modern Alarm (Android)

A small native Android Studio starter project with a dark modern UI.

## Build and install
1. Install Android Studio on a computer.
2. Open this `ModernAlarm` folder in Android Studio.
3. Let Gradle sync finish.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

## Important
- On Android 13+, allow notification permission.
- On Android 12+, allow **Alarms & reminders / exact alarms** when prompted.
- This starter schedules alarms while the app is installed. It uses a high-priority alarm notification with a Dismiss action; it does not yet provide a full-screen ringing screen or restore alarms after a device reboot.
- Device battery restrictions and manufacturer settings can affect alarm delivery. Test it before relying on it.
